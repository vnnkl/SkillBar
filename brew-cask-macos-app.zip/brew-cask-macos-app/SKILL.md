---
name: brew-cask-macos-app
description: This skill should be used when distributing any macOS application or CLI tool via Homebrew. Covers Homebrew formulas (CLI tools built from source or prebuilt binaries), Homebrew Casks (.app, .dmg, .pkg, .zip), custom taps, and automated release pipelines. Works with Swift/SPM, Electron, Tauri, Go, Rust, Flutter, Python, and any other stack. Triggers on requests like "distribute via homebrew", "create a brew cask", "set up homebrew tap", "make installable with brew", "package for homebrew", or "create a formula".
---

# Homebrew Distribution

## Overview

Distribute macOS applications and CLI tools via Homebrew. This skill covers the full pipeline: packaging, signing, release artifacts, tap setup, and cask/formula authoring. Works with any technology stack.

## Decision: Formula vs Cask

| | **Formula** (`brew install`) | **Cask** (`brew install --cask`) |
|---|---|---|
| **For** | CLI tools, libraries, daemons | GUI apps (.app), system extensions |
| **Install to** | `$(brew --prefix)/bin` | `/Applications` |
| **Build** | From source (or bottled) | Pre-built binary only |
| **Artifact** | Binary, man pages, completions | .app, .dmg, .pkg, .zip |
| **Best for** | Go, Rust, Python, C CLI tools | Electron, Tauri, Swift, Flutter apps |
| **Automation** | GoReleaser, cargo-dist, brew create | Manual cask file or GoReleaser casks |

**Rule of thumb:** if it has a `.app` bundle or GUI, use a Cask. If it's a CLI binary, use a Formula. Some tools (e.g., a menu bar app with a CLI component) use both.

## Tap Setup

A tap is a GitHub repo named `USERNAME/homebrew-tap`. Homebrew strips the `homebrew-` prefix, so `brew tap user/tap` maps to the repo `user/homebrew-tap`.

```
homebrew-tap/
├── Formula/        # For formulas (CLI tools)
│   └── mytool.rb
└── Casks/          # For casks (GUI apps)
    └── myapp.rb
```

Create the repo: `gh repo create USERNAME/homebrew-tap --public --description "Homebrew tap"`

Install: `brew tap user/tap && brew install mytool` or `brew install --cask myapp`

## Cask Authoring (GUI Apps)

### Supported Artifact Types

| Stanza | Purpose | Used for |
|--------|---------|----------|
| `app` | Move `.app` to `/Applications` | Electron, Tauri, Swift, Flutter apps |
| `binary` | Symlink executable to `$(brew --prefix)/bin` | CLI tool bundled with GUI app |
| `pkg` | Install `.pkg` file (requires `uninstall` stanza) | macOS installer packages |
| `suite` | Move app suite directory to `/Applications` | Multi-app bundles (e.g., Office) |
| `installer` | Run executable installer | Custom installer scripts |

### Cask Template

```ruby
cask "appname" do
  version "1.0.0"
  sha256 "SHA256_HASH"

  url "https://github.com/USER/REPO/releases/download/v#{version}/AppName-#{version}.zip"
  name "AppName"
  desc "Short description under 80 characters"
  homepage "https://github.com/USER/REPO"

  depends_on macos: ">= :sonoma"  # :ventura, :monterey, :big_sur

  app "AppName.app"

  # Optional: CLI binary bundled with app
  # binary "#{appdir}/AppName.app/Contents/MacOS/appname-cli", target: "appname"

  # Optional: completions
  # zsh_completion "completions/_appname"

  zap trash: [
    "~/Library/Preferences/com.user.AppName.plist",
    "~/Library/Application Support/AppName",
  ]
end
```

### Cask for .dmg

```ruby
cask "appname" do
  version "1.0.0"
  sha256 "SHA256_HASH"

  url "https://example.com/AppName-#{version}.dmg"
  name "AppName"
  desc "Short description"
  homepage "https://example.com"

  app "AppName.app"
end
```

### Cask for .pkg (requires uninstall stanza)

```ruby
cask "appname" do
  version "1.0.0"
  sha256 "SHA256_HASH"

  url "https://example.com/AppName-#{version}.pkg"
  name "AppName"
  desc "Short description"
  homepage "https://example.com"

  pkg "AppName-#{version}.pkg"

  uninstall pkgutil: "com.user.AppName"

  zap trash: "~/Library/Preferences/com.user.AppName.plist"
end
```

## Formula Authoring (CLI Tools)

### Go CLI (with GoReleaser)

GoReleaser auto-generates formulas. Add to `.goreleaser.yaml`:

```yaml
brews:
  - repository:
      owner: USERNAME
      name: homebrew-tap
    homepage: "https://github.com/USER/REPO"
    description: "Tool description"
    install: |
      bin.install "mytool"
    test: |
      system "#{bin}/mytool", "--version"
```

Then `goreleaser release` pushes the formula automatically.

### Rust CLI (with cargo-dist)

cargo-dist generates Homebrew formulas. In `Cargo.toml`:

```toml
[workspace.metadata.dist]
installers = ["homebrew"]

[workspace.metadata.dist.homebrew]
tap = "USERNAME/homebrew-tap"
formula = "mytool"
```

Then `cargo dist build && cargo dist publish` handles everything.

### Manual Formula (any language)

```ruby
class Mytool < Formula
  desc "Short description"
  homepage "https://github.com/USER/REPO"
  url "https://github.com/USER/REPO/releases/download/v1.0.0/mytool-1.0.0-darwin-arm64.tar.gz"
  sha256 "SHA256_HASH"
  license "MIT"

  # For universal binary support:
  # on_arm do
  #   url "...arm64.tar.gz"
  #   sha256 "ARM_SHA"
  # end
  # on_intel do
  #   url "...amd64.tar.gz"
  #   sha256 "INTEL_SHA"
  # end

  def install
    bin.install "mytool"
    # Optional:
    # man1.install "mytool.1"
    # bash_completion.install "completions/mytool.bash" => "mytool"
    # zsh_completion.install "completions/_mytool"
    # fish_completion.install "completions/mytool.fish"
  end

  test do
    system "#{bin}/mytool", "--version"
  end
end
```

### Build-from-source Formula (Go)

```ruby
class Mytool < Formula
  desc "Short description"
  homepage "https://github.com/USER/REPO"
  url "https://github.com/USER/REPO/archive/refs/tags/v1.0.0.tar.gz"
  sha256 "SHA256_HASH"
  license "MIT"

  depends_on "go" => :build

  def install
    system "go", "build", *std_go_args(ldflags: "-s -w -X main.version=#{version}")
  end

  test do
    system "#{bin}/mytool", "--version"
  end
end
```

### Build-from-source Formula (Rust)

```ruby
class Mytool < Formula
  desc "Short description"
  homepage "https://github.com/USER/REPO"
  url "https://github.com/USER/REPO/archive/refs/tags/v1.0.0.tar.gz"
  sha256 "SHA256_HASH"
  license "MIT"

  depends_on "rust" => :build

  def install
    system "cargo", "install", *std_cargo_args
  end

  test do
    system "#{bin}/mytool", "--version"
  end
end
```

## Packaging by Stack

### Swift/SPM → .app Cask

1. Create `version.env` with `VERSION` and `BUILD_NUMBER`
2. Create `Resources/Info.plist.template` with `__VERSION__`/`__BUILD__` placeholders
3. Generate icon: render to PNG, `sips` resize to iconset sizes, `iconutil -c icns`
4. Build: `swift build -c release --arch arm64`
5. Assemble `build/App.app/Contents/{MacOS,Resources}/` — binary, Info.plist, icon
6. Sign: `codesign --force --sign - --deep` (ad-hoc)
7. ZIP: `ditto -c -k --keepParent App.app App-VERSION.zip`
8. SHA: `shasum -a 256`

Refer to `references/templates.md` for complete script templates.

### Electron → .app/.dmg Cask

electron-builder produces `.dmg` and `.zip` artifacts natively:

```json
{
  "build": {
    "mac": {
      "target": ["dmg", "zip"],
      "category": "public.app-category.developer-tools"
    }
  }
}
```

- Always enable both `dmg` and `zip` targets (Squirrel auto-update needs both)
- Use `electron-builder --mac` to build
- Cask uses the `.zip` or `.dmg` from GitHub Releases
- Set `auto_updates true` in cask if app has built-in auto-updater
- Use `livecheck` with `:electron_builder` strategy for version detection

### Tauri → .app/.dmg Cask

Tauri produces `.dmg` and `.app` bundles via `tauri build`:

```bash
cargo tauri build
```

- Output in `src-tauri/target/release/bundle/`
- Much smaller bundles than Electron (uses system WebView)
- Tauri 2.0+ supports both arm64 and x86_64 via `--target`
- ZIP the `.app` for cask distribution: `ditto -c -k --keepParent`

### Go CLI → Formula

Use GoReleaser (recommended) for automated formula generation, or create a manual formula. GoReleaser handles cross-compilation, checksums, and formula push in one step.

### Rust CLI → Formula

Use cargo-dist (recommended) for automated formula generation, or create a manual formula. cargo-dist auto-detects linked dependencies and adds them to the formula.

### Python CLI → Formula

```ruby
class Mytool < Formula
  include Language::Python::Virtualenv

  desc "Short description"
  homepage "https://github.com/USER/REPO"
  url "https://files.pythonhosted.org/packages/.../mytool-1.0.0.tar.gz"
  sha256 "SHA256_HASH"
  license "MIT"

  depends_on "python@3.12"

  def install
    virtualenv_install_with_resources
  end

  test do
    system "#{bin}/mytool", "--version"
  end
end
```

### Flutter → .app/.dmg Cask

```bash
flutter build macos
```

Output at `build/macos/Build/Products/Release/AppName.app`. ZIP and distribute like any other `.app` bundle.

## Release Checklist

1. Bump version in your project's version source
2. Build release artifact (binary, .app, .dmg, .pkg)
3. For casks: ZIP with `ditto -c -k --keepParent` (preserves macOS extended attributes)
4. Compute SHA256: `shasum -a 256 artifact.zip`
5. Tag: `git tag vX.Y.Z && git push origin vX.Y.Z`
6. Release: `gh release create vX.Y.Z artifact.zip --title "vX.Y.Z"`
7. Update formula/cask SHA256 in tap repo, commit, push
8. Verify: `brew tap user/tap && brew install [--cask] appname`

## Gotchas

- **ditto vs zip**: always use `ditto -c -k --keepParent` for `.app` bundles — regular `zip` strips macOS extended attributes and can break code signatures.
- **Ad-hoc signing**: works for direct distribution but triggers Gatekeeper warning. Users must right-click > Open or `xattr -cr App.app`. Use a Developer ID certificate for proper notarized distribution.
- **auto_updates**: set `auto_updates true` in a cask if the app has a built-in updater (Sparkle, electron-updater, Tauri updater). This tells Homebrew not to manage updates.
- **Tap naming**: repo must be `homebrew-tap` (or `homebrew-TAPNAME`). Homebrew strips the `homebrew-` prefix.
- **Universal binaries**: for arm64+x86_64 support, use `on_arm`/`on_intel` blocks in formulas, or build universal binaries with `lipo` / `--arch arm64 --arch x86_64`.
- **Formula vs Cask**: never use a cask for a pure CLI tool. Never use a formula for a GUI-only app. Use both stanzas if the app has both a GUI and CLI component.
- **pkg casks**: always include an `uninstall` stanza with `pkgutil:` to specify the package identifier.
- **livecheck**: add a `livecheck` block so `brew livecheck` can detect new versions automatically.

## Resources

### references/

- `references/templates.md` — complete file templates for Swift/SPM .app packaging: version.env, Info.plist.template, generate_icon.sh, package_app.sh, release.sh. Load when setting up a Swift menu bar app for Homebrew distribution.
