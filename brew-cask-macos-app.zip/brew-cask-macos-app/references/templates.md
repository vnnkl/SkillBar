# File Templates for .app Bundle + Homebrew Cask

Complete, copy-paste-ready templates. Replace placeholders: `__APP_NAME__`, `__BUNDLE_ID__`, `__MIN_MACOS__`, `__GITHUB_USER__`, `__GITHUB_REPO__`.

## version.env

```bash
VERSION=0.1.0
BUILD_NUMBER=1
```

## Resources/Info.plist.template

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleDevelopmentRegion</key>
	<string>en</string>
	<key>CFBundleExecutable</key>
	<string>__APP_NAME__</string>
	<key>CFBundleIconFile</key>
	<string>AppIcon</string>
	<key>CFBundleIdentifier</key>
	<string>__BUNDLE_ID__</string>
	<key>CFBundleInfoDictionaryVersion</key>
	<string>6.0</string>
	<key>CFBundleName</key>
	<string>__APP_NAME__</string>
	<key>CFBundlePackageType</key>
	<string>APPL</string>
	<key>CFBundleShortVersionString</key>
	<string>__VERSION__</string>
	<key>CFBundleVersion</key>
	<string>__BUILD__</string>
	<key>LSMinimumSystemVersion</key>
	<string>__MIN_MACOS__</string>
	<key>LSUIElement</key>
	<true/>
	<key>NSHighResolutionCapable</key>
	<true/>
	<key>NSSupportsAutomaticTermination</key>
	<true/>
	<key>NSSupportsSuddenTermination</key>
	<false/>
</dict>
</plist>
```

Note: Remove `LSUIElement` for regular (non-menu-bar) apps.

## Scripts/generate_icon.sh

Generates `AppIcon.icns` from an SF Symbol rendered via inline Swift.

```bash
#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"
RESOURCES_DIR="$ROOT_DIR/Resources"
ICONSET_DIR="$ROOT_DIR/build/AppIcon.iconset"

mkdir -p "$ICONSET_DIR" "$RESOURCES_DIR"

MASTER_PNG="$ROOT_DIR/build/icon_master.png"

# Render SF Symbol to 1024x1024 PNG via Swift
# Change "terminal" to desired SF Symbol name
# Adjust colors in the gradient and tint as needed
/usr/bin/swift - "$MASTER_PNG" <<'SWIFT'
import AppKit

let outputPath = CommandLine.arguments[1]
let size = NSSize(width: 1024, height: 1024)

let image = NSImage(size: size, flipped: false) { rect in
    let bgPath = NSBezierPath(roundedRect: rect.insetBy(dx: 40, dy: 40), xRadius: 180, yRadius: 180)
    let gradient = NSGradient(
        starting: NSColor(red: 0.15, green: 0.15, blue: 0.20, alpha: 1.0),
        ending: NSColor(red: 0.08, green: 0.08, blue: 0.12, alpha: 1.0)
    )!
    gradient.draw(in: bgPath, angle: -90)

    NSColor(white: 0.3, alpha: 0.5).setStroke()
    bgPath.lineWidth = 4
    bgPath.stroke()

    let config = NSImage.SymbolConfiguration(pointSize: 420, weight: .medium)
    if let symbol = NSImage(systemSymbolName: "terminal", accessibilityDescription: nil)?
        .withSymbolConfiguration(config) {
        let symbolSize = symbol.size
        let x = (rect.width - symbolSize.width) / 2
        let y = (rect.height - symbolSize.height) / 2
        let drawRect = NSRect(x: x, y: y, width: symbolSize.width, height: symbolSize.height)

        symbol.draw(in: drawRect, from: .zero, operation: .sourceOver, fraction: 1.0)
        NSColor(red: 0.55, green: 0.8, blue: 1.0, alpha: 0.95).set()
        drawRect.fill(using: .sourceAtop)
    }
    return true
}

guard let tiff = image.tiffRepresentation,
      let bitmap = NSBitmapImageRep(data: tiff),
      let png = bitmap.representation(using: .png, properties: [:]) else {
    fputs("Error: Failed to render icon\n", stderr)
    exit(1)
}

do {
    try png.write(to: URL(fileURLWithPath: outputPath))
} catch {
    fputs("Error: \(error)\n", stderr)
    exit(1)
}
SWIFT

if [ ! -f "$MASTER_PNG" ]; then
    echo "Error: Failed to generate master icon"
    exit 1
fi

SIZES=(16 32 128 256 512)
for s in "${SIZES[@]}"; do
    sips -z "$s" "$s" "$MASTER_PNG" --out "$ICONSET_DIR/icon_${s}x${s}.png" >/dev/null
    d=$((s * 2))
    sips -z "$d" "$d" "$MASTER_PNG" --out "$ICONSET_DIR/icon_${s}x${s}@2x.png" >/dev/null
done
cp "$MASTER_PNG" "$ICONSET_DIR/icon_512x512@2x.png"

iconutil -c icns "$ICONSET_DIR" -o "$RESOURCES_DIR/AppIcon.icns"
rm -rf "$ICONSET_DIR" "$MASTER_PNG"

echo "Generated: $RESOURCES_DIR/AppIcon.icns"
```

Customize the SF Symbol name, colors, and background as needed.

## Scripts/package_app.sh

```bash
#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

source "$ROOT_DIR/version.env"

APP_NAME="__APP_NAME__"
APP_DIR="$ROOT_DIR/build/$APP_NAME.app"
CONTENTS_DIR="$APP_DIR/Contents"

echo "==> Building $APP_NAME v$VERSION (build $BUILD_NUMBER)..."

swift build -c release --package-path "$ROOT_DIR" --arch arm64

BINARY="$ROOT_DIR/.build/arm64-apple-macosx/release/$APP_NAME"
if [ ! -f "$BINARY" ]; then
    echo "Error: Binary not found at $BINARY"
    exit 1
fi

ICON="$ROOT_DIR/Resources/AppIcon.icns"
if [ ! -f "$ICON" ]; then
    echo "==> Generating app icon..."
    bash "$SCRIPT_DIR/generate_icon.sh"
fi

echo "==> Creating app bundle..."
rm -rf "$APP_DIR"
mkdir -p "$CONTENTS_DIR/MacOS" "$CONTENTS_DIR/Resources"

cp "$BINARY" "$CONTENTS_DIR/MacOS/$APP_NAME"

sed -e "s/__VERSION__/$VERSION/g" \
    -e "s/__BUILD__/$BUILD_NUMBER/g" \
    "$ROOT_DIR/Resources/Info.plist.template" > "$CONTENTS_DIR/Info.plist"

cp "$ICON" "$CONTENTS_DIR/Resources/AppIcon.icns"

echo "==> Signing (ad-hoc)..."
codesign --force --sign - --deep "$APP_DIR"

echo ""
echo "==> Success: $APP_DIR"
echo "    Version: $VERSION ($BUILD_NUMBER)"
echo "    Run: open $APP_DIR"
```

## Scripts/release.sh

```bash
#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

source "$ROOT_DIR/version.env"

APP_NAME="__APP_NAME__"
ZIP_NAME="$APP_NAME-$VERSION.zip"
ZIP_PATH="$ROOT_DIR/build/$ZIP_NAME"

echo "==> Building app bundle..."
bash "$SCRIPT_DIR/package_app.sh"

echo ""
echo "==> Creating release archive..."
cd "$ROOT_DIR/build"
ditto -c -k --keepParent "$APP_NAME.app" "$ZIP_NAME"
cd "$ROOT_DIR"

SHA=$(shasum -a 256 "$ZIP_PATH" | awk '{print $1}')

echo ""
echo "==> Release artifact ready"
echo "    File: $ZIP_PATH"
echo "    SHA256: $SHA"
echo ""
echo "Next steps:"
echo "  1. git tag v$VERSION && git push origin v$VERSION"
echo "  2. gh release create v$VERSION $ZIP_PATH --title \"v$VERSION\""
echo "  3. Update Homebrew cask SHA256 to: $SHA"
```

## Casks/appname.rb (Homebrew Cask)

```ruby
cask "appname" do
  version "0.1.0"
  sha256 "PLACEHOLDER"

  url "https://github.com/__GITHUB_USER__/__GITHUB_REPO__/releases/download/v#{version}/__APP_NAME__-#{version}.zip"
  name "__APP_NAME__"
  desc "Short description of the app"
  homepage "https://github.com/__GITHUB_USER__/__GITHUB_REPO__"

  depends_on macos: ">= :sonoma"

  app "__APP_NAME__.app"

  zap trash: "~/Library/Preferences/__BUNDLE_ID__.plist"
end
```

## .gitignore additions

```
build/
```

## Launch at Login (SwiftUI + SMAppService)

```swift
import ServiceManagement
import SwiftUI

// Runtime detection: only works when running as .app bundle
private var isAppBundle: Bool {
    Bundle.main.bundlePath.hasSuffix(".app")
}

// In a SwiftUI view with @State var launchAtLogin: Bool
// Read current state on appear:
.onAppear {
    if isAppBundle {
        launchAtLogin = SMAppService.mainApp.status == .enabled
    }
}

// Toggle:
private func toggleLaunchAtLogin(_ enabled: Bool) {
    do {
        if enabled {
            try SMAppService.mainApp.register()
        } else {
            try SMAppService.mainApp.unregister()
        }
        launchAtLogin = enabled
    } catch {
        // Handle error — show in UI
    }
}
```

No entitlements file needed. Works on macOS 13+ when running from a signed `.app` bundle with a valid `CFBundleIdentifier`.
